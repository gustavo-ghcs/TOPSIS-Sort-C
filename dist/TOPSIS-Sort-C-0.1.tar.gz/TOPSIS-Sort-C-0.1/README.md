# TOPSIS-Sort-C-SAD
Repositório destinado ao projeto da cadeira de Sistemas de Apoio à Decisão do Centro de Informática da UFPE.
